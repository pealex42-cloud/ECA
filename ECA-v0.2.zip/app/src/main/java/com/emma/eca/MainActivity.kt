package com.emma.eca

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

private val Leaf = Color(0xFF5E9E6E)
private val Deep = Color(0xFF1F3D2B)
private val Cream = Color(0xFFF3F7EE)
private val Sage = Color(0xFFDCEBD8)
private val Clay = Color(0xFFE8A88C)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())

    private var screen by mutableStateOf("home") // home, list, detail, edit
    private var timers by mutableStateOf(listOf<EcaTimer>())
    private var recipes by mutableStateOf(listOf<Recipe>())
    private var current by mutableStateOf<Recipe?>(null)
    private var heard by mutableStateOf("")
    private var reply by mutableStateOf("Appuie sur le micro, ou active le mode cuisine et dis « Chef »")
    private var listening by mutableStateOf(false)
    private var cooking by mutableStateOf(false)
    private var ringing by mutableStateOf<String?>(null)
    private var now by mutableLongStateOf(System.currentTimeMillis())

    private var speaking = false
    private var awaitUntil = 0L
    private var prevTimers = listOf<EcaTimer>()

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    private val startRunnable = Runnable { if (cooking && !speaking) startListening() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) {
                tts?.language = Locale.FRENCH
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { speaking = false; runOnUiThread { restart() } }
                    override fun onError(id: String?) { speaking = false; runOnUiThread { restart() } }
                })
            }
        }
        val need = mutableListOf<String>()
        if (!granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            need += Manifest.permission.POST_NOTIFICATIONS
        }
        if (need.isNotEmpty()) perms.launch(need.toTypedArray())
        refresh()
        loadRecipes()
        setContent { EcaApp() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onStop() {
        if (cooking) switchCooking(false)
        super.onStop()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------- Données ----------

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun refresh() { timers = TimerStore.load(this).sortedBy { it.endAt } }

    private fun loadRecipes() { recipes = RecipeStore.load(this).sortedBy { it.title.lowercase() } }

    private fun saveRecipe(r: Recipe) {
        RecipeStore.save(this, RecipeStore.load(this).filter { it.id != r.id } + r)
        loadRecipes()
    }

    private fun deleteRecipe(r: Recipe) {
        RecipeStore.save(this, RecipeStore.load(this).filter { it.id != r.id })
        loadRecipes()
    }

    private fun left(t: EcaTimer) = maxOf(0L, (t.endAt - System.currentTimeMillis()) / 1000)

    private fun addTimer(name: String, seconds: Long) {
        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val t = EcaTimer(id, name, System.currentTimeMillis() + seconds * 1000)
        TimerStore.save(this, TimerStore.load(this) + t)
        Alarms.schedule(this, t)
        refresh()
    }

    private fun removeTimer(t: EcaTimer) {
        Alarms.cancel(this, t)
        TimerStore.save(this, TimerStore.load(this).filter { it.id != t.id })
        refresh()
    }

    private fun find(q: String): EcaTimer? {
        if (q.isBlank()) return if (timers.size == 1) timers[0] else null
        val k = q.lowercase()
        return timers.firstOrNull { it.name.lowercase().contains(k) || k.contains(it.name.lowercase()) }
    }

    private fun notFound(q: String) =
        if (q.isBlank()) "Lequel ? Dis le nom du minuteur." else "Je ne trouve pas de minuteur $q."

    private fun fmtDate(t: Long) = SimpleDateFormat("dd/MM/yyyy 'à' HH:mm", Locale.FRANCE).format(Date(t))

    // ---------- Voix ----------

    private fun say(text: String) {
        reply = text
        if (cooking) {
            speaking = true
            recognizer?.cancel()
            handler.postDelayed({ if (speaking) { speaking = false; restart() } }, 10000)
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "eca")
    }

    private fun handle(text: String) {
        refresh()
        when (val c = Voice.parse(text)) {
            is Cmd.Start -> {
                addTimer(c.name, c.seconds)
                say("C'est parti : ${c.name}, ${Voice.fmt(c.seconds)}.")
            }
            is Cmd.Time -> {
                val cal = Calendar.getInstance()
                val m = cal.get(Calendar.MINUTE)
                say("Il est ${cal.get(Calendar.HOUR_OF_DAY)} heures" + if (m == 0) "." else " $m.")
            }
            is Cmd.Stop -> {
                getSystemService(NotificationManager::class.java).cancelAll()
                ringing = null
                val t = find(c.name)
                when {
                    t != null -> { removeTimer(t); say("Minuteur ${t.name} arrêté.") }
                    c.name.isBlank() -> say("D'accord, c'est coupé.")
                    else -> say(notFound(c.name))
                }
            }
            is Cmd.Remaining -> {
                val t = find(c.name)
                when {
                    t != null -> say("Il reste ${Voice.fmt(left(t))} pour ${t.name}.")
                    c.name.isBlank() && timers.isEmpty() -> say("Aucun minuteur en cours.")
                    c.name.isBlank() -> say(timers.joinToString(". ") { "${it.name} : ${Voice.fmt(left(it))}" })
                    else -> say(notFound(c.name))
                }
            }
            is Cmd.Unknown -> say(c.hint)
        }
    }

    /** Applique le mot d'activation « Chef » : seules les phrases qui le contiennent sont traitées en mode cuisine. */
    private fun process(text: String) {
        val m = Regex("\\bchef\\b[ ,.!?]*(.*)").find(text.lowercase())
        when {
            m != null -> {
                heard = text
                val rest = m.groupValues[1].trim()
                if (rest.isBlank()) {
                    awaitUntil = System.currentTimeMillis() + 10000
                    say("Oui ?")
                } else handle(rest)
            }
            awaitUntil > System.currentTimeMillis() -> {
                awaitUntil = 0
                heard = text
                handle(text)
            }
            !cooking -> { heard = text; handle(text) }
            else -> {} // mode cuisine : phrase sans « Chef », ignorée
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) { listening = true }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() { listening = false }
        override fun onError(e: Int) {
            listening = false
            if (cooking) {
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) switchCooking(false)
                else {
                    if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) recognizer?.cancel()
                    restart()
                }
            } else if (e != SpeechRecognizer.ERROR_CLIENT) {
                say("Je n'ai rien entendu, réessaie.")
            }
        }
        override fun onResults(res: Bundle?) {
            listening = false
            val text = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text != null) process(text)
            if (cooking) restart()
        }
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    private fun restart() {
        handler.removeCallbacks(startRunnable)
        if (cooking && !speaking) handler.postDelayed(startRunnable, 400)
    }

    private fun startListening() {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            cooking = false
            say("La reconnaissance vocale n'est pas disponible sur ce téléphone.")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        }
        recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        })
    }

    /** Bouton micro : la prochaine phrase est une commande, sans dire « Chef ». */
    private fun listen() {
        tts?.stop()
        speaking = false
        recognizer?.cancel()
        awaitUntil = System.currentTimeMillis() + 10000
        startListening()
    }

    private fun switchCooking(on: Boolean) {
        cooking = on
        if (on) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            say("Mode cuisine activé. Dis Chef, puis ta commande.")
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            handler.removeCallbacks(startRunnable)
            recognizer?.cancel()
            tts?.stop()
            speaking = false
            listening = false
            reply = "Mode cuisine désactivé."
        }
    }

    // ---------- Interface ----------

    @Composable
    private fun EcaApp() {
        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = Leaf, onPrimary = Color.White,
                background = Cream, onBackground = Deep,
                surface = Sage, onSurface = Deep
            )
        ) {
            LaunchedEffect(Unit) {
                while (true) {
                    now = System.currentTimeMillis()
                    refresh()
                    val old = prevTimers
                    prevTimers = timers
                    old.filter { o -> timers.none { it.id == o.id } && o.endAt <= now + 2500 }
                        .forEach { ringing = it.name }
                    delay(1000)
                }
            }
            BackHandler(enabled = screen != "home") {
                screen = when (screen) {
                    "edit" -> if (current != null) "detail" else "list"
                    "detail" -> "list"
                    else -> "home"
                }
            }
            Box(Modifier.fillMaxSize().background(Cream)) {
                when (screen) {
                    "list" -> RecipeList()
                    "detail" -> RecipeDetail()
                    "edit" -> RecipeEdit()
                    else -> Home()
                }
                if (bannerOn()) Box(Modifier.align(Alignment.TopCenter)) { Banner() }
            }
        }
    }

    private fun bannerOn() =
        (screen == "list" || screen == "detail") && (ringing != null || timers.isNotEmpty())

    /** Bandeau en surimpression : prochaine alarme, ou « c'est prêt ! » quand elle sonne. */
    @Composable
    private fun Banner() {
        val next = timers.minByOrNull { it.endAt }
        val r = ringing
        val ring = r != null
        Card(
            colors = CardDefaults.cardColors(containerColor = if (ring) Clay else Deep),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 12.dp)
                .clickable { if (ring) ringing = null else screen = "home" }
        ) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (ring) "⏰ $r : c'est prêt !" else "⏱ ${next?.name ?: ""}",
                    color = if (ring) Deep else Color.White,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (!ring && next != null) {
                    Text(
                        Voice.clock(maxOf(0L, (next.endAt - now) / 1000)),
                        color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    @Composable
    private fun Home() {
        var showAdd by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("🌿 Emma's Cook Assistant", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Leaf)
            Spacer(Modifier.height(12.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Sage),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(now)),
                        fontSize = 60.sp, fontWeight = FontWeight.Light, color = Deep
                    )
                    Text(
                        SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date(now))
                            .replaceFirstChar { it.uppercase() },
                        color = Deep
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { screen = "list" }, modifier = Modifier.weight(1f)) { Text("📖 Recettes") }
                Button(
                    onClick = { switchCooking(!cooking) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (cooking) Clay else Deep,
                        contentColor = if (cooking) Deep else Color.White
                    )
                ) { Text(if (cooking) "👂 Écoute activée" else "👂 Mode cuisine") }
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Minuteurs", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Deep, modifier = Modifier.weight(1f))
                TextButton(onClick = { showAdd = true }) { Text("+ Ajouter", color = Leaf) }
            }
            LazyColumn(Modifier.weight(1f)) {
                if (timers.isEmpty()) {
                    item { Text("Aucun minuteur en cours 🌱", color = Deep.copy(alpha = 0.6f), modifier = Modifier.padding(8.dp)) }
                }
                items(timers, key = { it.id }) { t ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(t.name, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Deep)
                                Text(Voice.clock(maxOf(0L, (t.endAt - now) / 1000)), fontSize = 28.sp, color = Leaf)
                            }
                            TextButton(onClick = { removeTimer(t) }) { Text("✕", fontSize = 20.sp, color = Clay) }
                        }
                    }
                }
            }
            if (heard.isNotBlank()) {
                Text("« $heard »", color = Deep.copy(alpha = 0.6f), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            Text(reply, color = Deep, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(8.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(80.dp).clip(CircleShape)
                        .background(if (listening) Clay else Leaf)
                        .clickable { listen() },
                    contentAlignment = Alignment.Center
                ) { Text("🎤", fontSize = 32.sp) }
            }
        }

        if (showAdd) {
            var name by remember { mutableStateOf("") }
            var min by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showAdd = false },
                title = { Text("Nouveau minuteur") },
                text = {
                    Column {
                        OutlinedTextField(name, { name = it }, label = { Text("Nom (pâte, gratin…)") }, singleLine = true)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(min, { min = it.filter(Char::isDigit) }, label = { Text("Minutes") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val m = min.toLongOrNull()
                        if (m != null && m > 0) {
                            addTimer(name.ifBlank { "Minuteur" }, m * 60)
                            showAdd = false
                        }
                    }) { Text("Lancer") }
                },
                dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Annuler") } }
            )
        }
    }

    @Composable
    private fun RecipeList() {
        var q by remember { mutableStateOf("") }
        val shown = recipes.filter { q.isBlank() || it.title.contains(q, true) || it.ingredients.contains(q, true) }
        Column(
            Modifier.fillMaxSize().padding(horizontal = 20.dp)
                .padding(top = if (bannerOn()) 76.dp else 20.dp, bottom = 20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { screen = "home" }) { Text("← Retour", color = Leaf) }
                Spacer(Modifier.weight(1f))
                Button(onClick = { current = null; screen = "edit" }) { Text("+ Nouvelle recette") }
            }
            Text("Recettes", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Deep)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(q, { q = it }, label = { Text("Rechercher") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                if (shown.isEmpty()) {
                    item {
                        Text(
                            "Aucune recette pour l'instant 🌱\nAppuie sur « + Nouvelle recette ».",
                            color = Deep.copy(alpha = 0.6f), modifier = Modifier.padding(8.dp)
                        )
                    }
                }
                items(shown, key = { it.id }) { r ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                            .clickable { current = r; screen = "detail" }
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(r.title, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Deep)
                            Text("Modifiée le ${fmtDate(r.updatedAt)}", fontSize = 12.sp, color = Deep.copy(alpha = 0.6f))
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun RecipeDetail() {
        val r = current ?: return
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp).padding(top = if (bannerOn()) 76.dp else 20.dp, bottom = 20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { screen = "list" }) { Text("← Retour", color = Leaf) }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { screen = "edit" }) { Text("✏️ Modifier", color = Leaf) }
            }
            Text(r.title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Deep)
            Text("Modifiée le ${fmtDate(r.updatedAt)}", fontSize = 12.sp, color = Deep.copy(alpha = 0.6f))
            Spacer(Modifier.height(16.dp))
            Text("Ingrédients", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Leaf)
            Text(r.ingredients, color = Deep, modifier = Modifier.padding(vertical = 6.dp))
            Spacer(Modifier.height(12.dp))
            Text("Étapes", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Leaf)
            r.steps.lines().filter { it.isNotBlank() }.forEachIndexed { i, line ->
                val secs = Voice.duration(line)
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}. $line", color = Deep, modifier = Modifier.weight(1f))
                        if (secs > 0) {
                            TextButton(onClick = { addTimer("${r.title} (étape ${i + 1})", secs) }) {
                                Text("⏱ ${Voice.fmt(secs)}", color = Leaf)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            TextButton(onClick = { deleteRecipe(r); current = null; screen = "list" }) {
                Text("🗑 Supprimer cette recette", color = Clay)
            }
        }
    }

    @Composable
    private fun RecipeEdit() {
        val r = current
        var title by remember { mutableStateOf(r?.title ?: "") }
        var ing by remember { mutableStateOf(r?.ingredients ?: "") }
        var steps by remember { mutableStateOf(r?.steps ?: "") }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { screen = if (r != null) "detail" else "list" }) { Text("Annuler", color = Leaf) }
                Spacer(Modifier.weight(1f))
                Button(onClick = {
                    if (title.isNotBlank()) {
                        val saved = Recipe(
                            r?.id ?: System.currentTimeMillis(), title.trim(),
                            ing.trim(), steps.trim(), System.currentTimeMillis()
                        )
                        saveRecipe(saved)
                        current = saved
                        screen = "detail"
                    }
                }) { Text("Enregistrer") }
            }
            Text(if (r == null) "Nouvelle recette" else "Modifier la recette", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Deep)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(title, { title = it }, label = { Text("Nom de la recette") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(ing, { ing = it }, label = { Text("Ingrédients (un par ligne)") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(steps, { steps = it }, label = { Text("Étapes (une par ligne)") }, minLines = 6, modifier = Modifier.fillMaxWidth())
            Text(
                "Astuce : écris la durée dans l'étape (« Cuire 25 min ») et un bouton ⏱ apparaîtra pour lancer le minuteur.",
                fontSize = 12.sp, color = Deep.copy(alpha = 0.6f), modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
