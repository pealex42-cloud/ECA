package com.emma.eca

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var timers by mutableStateOf(listOf<EcaTimer>())
    private var heard by mutableStateOf("")
    private var reply by mutableStateOf("Appuie sur le micro et dis par exemple : « minuteur pâte 45 minutes »")
    private var listening by mutableStateOf(false)

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.FRENCH }
        val need = mutableListOf<String>()
        if (!granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            need += Manifest.permission.POST_NOTIFICATIONS
        }
        if (need.isNotEmpty()) perms.launch(need.toTypedArray())
        refresh()
        setContent { EcaApp() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun refresh() {
        timers = TimerStore.load(this).sortedBy { it.endAt }
    }

    private fun say(text: String) {
        reply = text
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "eca")
    }

    private fun left(t: EcaTimer) = maxOf(0L, (t.endAt - System.currentTimeMillis()) / 1000)

    private fun addTimer(name: String, seconds: Long) {
        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val t = EcaTimer(id, name, System.currentTimeMillis() + seconds * 1000)
        TimerStore.save(this, TimerStore.load(this) + t)
        Alarms.schedule(this, t)
        refresh()
    }

    private fun removeTimer(t: EcaTimer) {
        Alarms.cancel(this, t)
        TimerStore.save(this, TimerStore.load(this).filter { it.id != t.id })
        refresh()
    }

    private fun find(q: String): EcaTimer? {
        if (q.isBlank()) return if (timers.size == 1) timers[0] else null
        val k = q.lowercase()
        return timers.firstOrNull { it.name.lowercase().contains(k) || k.contains(it.name.lowercase()) }
    }

    private fun notFound(q: String) =
        if (q.isBlank()) "Lequel ? Dis le nom du minuteur." else "Je ne trouve pas de minuteur $q."

    private fun handle(text: String) {
        refresh()
        when (val c = Voice.parse(text)) {
            is Cmd.Start -> {
                addTimer(c.name, c.seconds)
                say("C'est parti : ${c.name}, ${Voice.fmt(c.seconds)}.")
            }
            is Cmd.Time -> {
                val cal = Calendar.getInstance()
                val m = cal.get(Calendar.MINUTE)
                say("Il est ${cal.get(Calendar.HOUR_OF_DAY)} heures" + if (m == 0) "." else " $m.")
            }
            is Cmd.Stop -> {
                val t = find(c.name)
                if (t != null) {
                    removeTimer(t)
                    say("Minuteur ${t.name} arrêté.")
                } else say(notFound(c.name))
            }
            is Cmd.Remaining -> {
                val t = find(c.name)
                when {
                    t != null -> say("Il reste ${Voice.fmt(left(t))} pour ${t.name}.")
                    c.name.isBlank() && timers.isEmpty() -> say("Aucun minuteur en cours.")
                    c.name.isBlank() -> say(timers.joinToString(". ") { "${it.name} : ${Voice.fmt(left(it))}" })
                    else -> say(notFound(c.name))
                }
            }
            is Cmd.Unknown -> say(c.hint)
        }
    }

    private fun listen() {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("La reconnaissance vocale n'est pas disponible sur ce téléphone.")
            return
        }
        tts?.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { listening = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onError(e: Int) {
                    listening = false
                    say("Je n'ai rien entendu, réessaie.")
                }
                override fun onResults(res: Bundle?) {
                    listening = false
                    val text = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                    heard = text
                    handle(text)
                }
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            })
        }
    }

    @Composable
    private fun EcaApp() {
        val leaf = Color(0xFF5E9E6E)
        val deep = Color(0xFF1F3D2B)
        val cream = Color(0xFFF3F7EE)
        val sage = Color(0xFFDCEBD8)
        val clay = Color(0xFFE8A88C)

        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = leaf, onPrimary = Color.White,
                background = cream, onBackground = deep,
                surface = sage, onSurface = deep
            )
        ) {
            var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
            var showAdd by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) {
                while (true) {
                    now = System.currentTimeMillis()
                    refresh()
                    delay(1000)
                }
            }

            Column(Modifier.fillMaxSize().background(cream).padding(20.dp)) {
                Text("🌿 Emma's Cook Assistant", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = leaf)
                Spacer(Modifier.height(12.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = sage),
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(now)),
                            fontSize = 64.sp, fontWeight = FontWeight.Light, color = deep
                        )
                        Text(
                            SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date(now))
                                .replaceFirstChar { it.uppercase() },
                            color = deep
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Minuteurs", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = deep, modifier = Modifier.weight(1f))
                    TextButton(onClick = { showAdd = true }) { Text("+ Ajouter", color = leaf) }
                }
                LazyColumn(Modifier.weight(1f)) {
                    if (timers.isEmpty()) {
                        item { Text("Aucun minuteur en cours 🌱", color = deep.copy(alpha = 0.6f), modifier = Modifier.padding(8.dp)) }
                    }
                    items(timers, key = { it.id }) { t ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                        ) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(t.name, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = deep)
                                    Text(Voice.clock(maxOf(0L, (t.endAt - now) / 1000)), fontSize = 28.sp, color = leaf)
                                }
                                TextButton(onClick = { removeTimer(t) }) { Text("✕", fontSize = 20.sp, color = clay) }
                            }
                        }
                    }
                }

                if (heard.isNotBlank()) {
                    Text("« $heard »", color = deep.copy(alpha = 0.6f), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
                Text(reply, color = deep, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(8.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier.size(88.dp).clip(CircleShape)
                            .background(if (listening) clay else leaf)
                            .clickable { listen() },
                        contentAlignment = Alignment.Center
                    ) { Text("🎤", fontSize = 36.sp) }
                }
            }

            if (showAdd) {
                var name by remember { mutableStateOf("") }
                var min by remember { mutableStateOf("") }
                AlertDialog(
                    onDismissRequest = { showAdd = false },
                    title = { Text("Nouveau minuteur") },
                    text = {
                        Column {
                            OutlinedTextField(name, { name = it }, label = { Text("Nom (pâte, gratin…)") }, singleLine = true)
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(min, { min = it.filter(Char::isDigit) }, label = { Text("Minutes") }, singleLine = true)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val m = min.toLongOrNull()
                            if (m != null && m > 0) {
                                addTimer(name.ifBlank { "Minuteur" }, m * 60)
                                showAdd = false
                            }
                        }) { Text("Lancer") }
                    },
                    dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Annuler") } }
                )
            }
        }
    }
}
