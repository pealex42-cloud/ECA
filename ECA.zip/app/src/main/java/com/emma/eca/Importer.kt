package com.emma.eca

import android.text.Html
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Imported(val title: String, val ingredients: String, val steps: String, val source: String)

class ImportException(msg: String) : Exception(msg)

/** Import d'une recette depuis une page web ou une vidéo TikTok. */
object Importer {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
    private const val NL = "§§"

    fun extractUrl(text: String): String? =
        Regex("https?://[^\\s]+").find(text)?.value?.trimEnd('.', ',', ')', ';')

    fun isTikTok(url: String) =
        Regex("^https?://([\\w-]+\\.)*tiktok\\.com/", RegexOption.IGNORE_CASE).containsMatchIn(url)

    fun load(rawUrl: String): Imported {
        val url = rawUrl.replaceFirst("http://", "https://")
        if (isTikTok(url)) return loadTikTok(url)
        val html = download(url)
        return parse(html, url) ?: throw ImportException(
            "Aucune recette trouvée sur cette page. Colle son texte dans « Texte ou photo », ou recopie-la dans « + Nouvelle »."
        )
    }

    // ---------- Réseau ----------

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json")
        c.setRequestProperty("Accept-Language", "fr-FR,fr;q=0.9")
        return c
    }

    private fun download(start: String): String {
        var url = start
        repeat(6) {
            val c = open(url)
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw ImportException("Redirection invalide.")
                url = URL(URL(url), loc).toString().replaceFirst("http://", "https://")
                c.disconnect()
            } else {
                if (code != 200) {
                    throw ImportException("Le site a refusé l'accès (code $code). Essaie de recopier la recette à la main.")
                }
                val name = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE)
                    .find(c.contentType ?: "")?.groupValues?.get(1) ?: "UTF-8"
                val cs = try { charset(name) } catch (e: Exception) { Charsets.UTF_8 }
                val bytes = c.inputStream.use { it.readBytes() }
                return String(bytes, cs)
            }
        }
        throw ImportException("Trop de redirections.")
    }

    private fun resolve(start: String): String {
        var url = start
        repeat(5) {
            val c = open(url)
            val code = c.responseCode
            val loc = c.getHeaderField("Location")
            c.disconnect()
            if (code in 300..399 && loc != null) url = URL(URL(url), loc).toString().replaceFirst("http://", "https://")
            else return url
        }
        return url
    }

    // ---------- TikTok ----------

    private fun loadTikTok(start: String): Imported {
        var url = start
        val u = URL(url)
        if (u.host.lowercase().let { it.startsWith("vm.") || it.startsWith("vt.") } || u.path.startsWith("/t/")) {
            url = resolve(url)
        }
        val api = "https://www.tiktok.com/oembed?url=" + URLEncoder.encode(url, "UTF-8")
        val body = try {
            download(api)
        } catch (e: ImportException) {
            throw ImportException("TikTok n'a pas donné la légende de cette vidéo. Essaie « Texte ou photo » avec une capture d'écran.")
        }
        val caption = try { JSONObject(body).optString("title", "") } catch (e: Exception) { "" }
        val p = TextParser.parse(caption)
        if (caption.isBlank() || (p.ingredients.isBlank() && p.steps.isBlank())) {
            throw ImportException(
                "La légende ne contient pas la recette (elle est souvent dans la vidéo ou les commentaires). " +
                    "Colle le texte ou une capture d'écran dans « Texte ou photo »."
            )
        }
        return Imported(p.title.ifBlank { "Recette TikTok" }, p.ingredients, p.steps, url)
    }

    // ---------- Pages web ----------

    fun parse(html: String, source: String): Imported? {
        val blocks = Regex(
            "<script[^>]*type=[\"']application/ld\\+json[\"'][^>]*>(.*?)</script>",
            setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
        ).findAll(html)
        var partial: Imported? = null
        for (m in blocks) {
            val value = try { JSONTokener(m.groupValues[1].trim()).nextValue() } catch (e: Exception) { continue }
            val recipe = findRecipe(value) ?: continue
            val imp = toImported(recipe, source)
            if (imp.ingredients.isNotBlank() && imp.steps.isNotBlank()) return imp
            if (partial == null) partial = imp
        }
        // données structurées absentes ou incomplètes : on lit le texte visible de la page
        val fb = fromText(html, source)
        val p = partial ?: return fb
        val merged = Imported(
            p.title,
            p.ingredients.ifBlank { fb?.ingredients ?: "" },
            p.steps.ifBlank { fb?.steps ?: "" },
            source
        )
        return if (merged.ingredients.isNotBlank() || merged.steps.isNotBlank()) merged else null
    }

    private fun findRecipe(v: Any?): JSONObject? {
        if (v is JSONArray) {
            for (i in 0 until v.length()) {
                val r = findRecipe(v.opt(i))
                if (r != null) return r
            }
        } else if (v is JSONObject) {
            if (isRecipe(v.opt("@type"))) return v
            return findRecipe(v.opt("@graph")) ?: findRecipe(v.opt("mainEntity"))
        }
        return null
    }

    private fun isRecipe(t: Any?): Boolean {
        if (t is String) return t.equals("Recipe", ignoreCase = true)
        if (t is JSONArray) {
            for (i in 0 until t.length()) {
                if ((t.opt(i) as? String)?.equals("Recipe", ignoreCase = true) == true) return true
            }
        }
        return false
    }

    private fun clean(s: String): String =
        Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().replace('\u00A0', ' ').trim()

    /** Comme clean(), mais garde les retours à la ligne (un texte peut contenir plusieurs étapes). */
    private fun cleanLines(s: String): List<String> =
        Html.fromHtml(
            s.replace(Regex("\\r?\\n"), NL)
                .replace(Regex("<br\\s*/?>|</p>|</li>|</div>", RegexOption.IGNORE_CASE), NL),
            Html.FROM_HTML_MODE_LEGACY
        ).toString().replace('\u00A0', ' ').split(NL).map { it.trim() }.filter { it.isNotBlank() }

    private fun titleOf(s: String): String = clean(s).split(" | ", " - ", " – ").first().trim()

    private fun toImported(r: JSONObject, source: String): Imported {
        val title = titleOf(r.optString("name", "")).ifBlank { "Recette importée" }
        var ing = strings(r.opt("recipeIngredient"))
        if (ing.size == 1 && ing[0].length > 40) {
            val parts = ing[0].split(Regex("\\s*(?:,\\s+|;\\s*|•\\s*)")).filter { it.isNotBlank() }
            if (parts.size >= 3) ing = parts
        }
        val steps = steps(r.opt("recipeInstructions")).flatMap { TextParser.splitLong(it) }
        return Imported(title, ing.joinToString("\n"), steps.joinToString("\n"), source)
    }

    private fun strings(v: Any?): List<String> {
        val out = mutableListOf<String>()
        if (v is String) out.add(clean(v))
        else if (v is JSONArray) for (i in 0 until v.length()) out.addAll(strings(v.opt(i)))
        return out.filter { it.isNotBlank() }
    }

    private fun steps(v: Any?): List<String> {
        val out = mutableListOf<String>()
        if (v is String) {
            out.addAll(cleanLines(v))
        } else if (v is JSONArray) {
            for (i in 0 until v.length()) out.addAll(steps(v.opt(i)))
        } else if (v is JSONObject) {
            val items = v.opt("itemListElement")
            if (items is JSONArray) out.addAll(steps(items))
            else out.addAll(cleanLines(v.optString("text", v.optString("name", ""))))
        }
        return out.map { it.replace(Regex("^\\d+\\s*[.)](?!\\d)\\s*"), "") }.filter { it.isNotBlank() }
    }

    /** Dernier recours : lit le texte visible de la page à partir du mot « Ingrédients ». */
    private fun fromText(html: String, source: String): Imported? {
        val titleRaw = Regex("<meta[^>]+property=[\"']og:title[\"'][^>]+content=[\"']([^\"']*)[\"']", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)
            ?: Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
                .find(html)?.groupValues?.get(1)
        val title = titleRaw?.let { titleOf(it) }
        var t = html.replace(
            Regex("<(script|style|noscript|nav|header|footer|aside)\\b[^>]*>.*?</\\1>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)),
            " "
        )
        t = t.replace(Regex("</?(?:br|p|li|div|h[1-6]|tr|section|article|ul|ol)\\b[^>]*>", RegexOption.IGNORE_CASE), NL)
        val text = Html.fromHtml(t, Html.FROM_HTML_MODE_LEGACY).toString().replace('\u00A0', ' ').replace(NL, "\n")
        val starts = Regex("ingr[ée]dients", RegexOption.IGNORE_CASE).findAll(text).map { it.range.first }.take(6).toList()
        for (i in starts) {
            val p = TextParser.parse(text.substring(i).take(8000), title)
            if (p.ingredients.lines().count { it.isNotBlank() } >= 3 && p.steps.isNotBlank()) {
                return Imported(p.title, p.ingredients, p.steps, source)
            }
        }
        return null
    }
}
