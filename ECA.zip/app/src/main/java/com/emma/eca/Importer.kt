package com.emma.eca

import android.text.Html
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL

data class Imported(val title: String, val ingredients: String, val steps: String, val source: String)

class ImportException(msg: String) : Exception(msg)

/** Import d'une recette depuis une page web : lit les données « Recipe » (JSON-LD) que la plupart des sites publient. */
object Importer {
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    fun extractUrl(text: String): String? =
        Regex("https?://[^\\s]+").find(text)?.value?.trimEnd('.', ',', ')', ';')

    fun load(rawUrl: String): Imported {
        val url = rawUrl.replaceFirst("http://", "https://")
        val html = download(url)
        return parse(html, url)
            ?: throw ImportException(
                "Aucune recette trouvée sur cette page. Tu peux la recopier dans « + Nouvelle »."
            )
    }

    private fun download(start: String): String {
        var url = start
        repeat(6) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 10000
            c.readTimeout = 15000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml")
            c.setRequestProperty("Accept-Language", "fr-FR,fr;q=0.9")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw ImportException("Redirection invalide.")
                url = URL(URL(url), loc).toString().replaceFirst("http://", "https://")
                c.disconnect()
            } else {
                if (code != 200) {
                    throw ImportException("Le site a refusé l'accès (code $code). Essaie de recopier la recette à la main.")
                }
                val name = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE)
                    .find(c.contentType ?: "")?.groupValues?.get(1) ?: "UTF-8"
                val cs = try { charset(name) } catch (e: Exception) { Charsets.UTF_8 }
                val bytes = c.inputStream.use { it.readBytes() }
                return String(bytes, cs)
            }
        }
        throw ImportException("Trop de redirections.")
    }

    fun parse(html: String, source: String): Imported? {
        val blocks = Regex(
            "<script[^>]*type=[\"']application/ld\\+json[\"'][^>]*>(.*?)</script>",
            setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
        ).findAll(html)
        for (m in blocks) {
            val value = try { JSONTokener(m.groupValues[1].trim()).nextValue() } catch (e: Exception) { continue }
            val recipe = findRecipe(value) ?: continue
            return toImported(recipe, source)
        }
        return null
    }

    private fun findRecipe(v: Any?): JSONObject? {
        if (v is JSONArray) {
            for (i in 0 until v.length()) {
                val r = findRecipe(v.opt(i))
                if (r != null) return r
            }
        } else if (v is JSONObject) {
            if (isRecipe(v.opt("@type"))) return v
            return findRecipe(v.opt("@graph")) ?: findRecipe(v.opt("mainEntity"))
        }
        return null
    }

    private fun isRecipe(t: Any?): Boolean {
        if (t is String) return t.equals("Recipe", ignoreCase = true)
        if (t is JSONArray) {
            for (i in 0 until t.length()) {
                if ((t.opt(i) as? String)?.equals("Recipe", ignoreCase = true) == true) return true
            }
        }
        return false
    }

    private fun clean(s: String): String =
        Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().replace('\u00A0', ' ').trim()

    private fun toImported(r: JSONObject, source: String): Imported {
        val title = clean(r.optString("name", "")).ifBlank { "Recette importée" }
        val ingredients = strings(r.opt("recipeIngredient")).joinToString("\n")
        val steps = steps(r.opt("recipeInstructions")).joinToString("\n")
        return Imported(title, ingredients, steps, source)
    }

    private fun strings(v: Any?): List<String> {
        val out = mutableListOf<String>()
        if (v is String) out.add(clean(v))
        else if (v is JSONArray) for (i in 0 until v.length()) out.addAll(strings(v.opt(i)))
        return out.filter { it.isNotBlank() }
    }

    private fun steps(v: Any?): List<String> {
        val out = mutableListOf<String>()
        if (v is String) {
            out.addAll(clean(v).lines())
        } else if (v is JSONArray) {
            for (i in 0 until v.length()) out.addAll(steps(v.opt(i)))
        } else if (v is JSONObject) {
            val items = v.opt("itemListElement")
            if (items is JSONArray) out.addAll(steps(items))
            else out.add(clean(v.optString("text", v.optString("name", ""))))
        }
        return out.map { it.trim().replace(Regex("^\\d+\\s*[.)]\\s+"), "") }.filter { it.isNotBlank() }
    }
}
