package com.emma.eca

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

private val Leaf = Color(0xFF5E9E6E)
private val Deep = Color(0xFF1F3D2B)
private val Cream = Color(0xFFF3F7EE)
private val Sage = Color(0xFFDCEBD8)
private val Clay = Color(0xFFE8A88C)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())

    private var screen by mutableStateOf("home") // home, list, detail, edit
    private var timers by mutableStateOf(listOf<EcaTimer>())
    private var recipes by mutableStateOf(listOf<Recipe>())
    private var current by mutableStateOf<Recipe?>(null)
    private var heard by mutableStateOf("")
    private var reply by mutableStateOf("Appuie sur le micro, ou active le mode cuisine et dis « Chef »")
    private var listening by mutableStateOf(false)
    private var cooking by mutableStateOf(false)
    private var ringing by mutableStateOf<String?>(null)
    private var now by mutableLongStateOf(System.currentTimeMillis())
    private var cookSteps by mutableStateOf(listOf<String>())
    private var cookIndex by mutableIntStateOf(0)
    private var showIngredients by mutableStateOf(false)
    private var draft by mutableStateOf<Recipe?>(null)
    private var importUrl by mutableStateOf("")
    private var importStatus by mutableStateOf("")
    private var importing by mutableStateOf(false)
    private var scanText by mutableStateOf("")
    private var photoUri: Uri? = null

    private var speaking = false
    private var awaitUntil = 0L
    private var prevTimers = listOf<EcaTimer>()
    private var lastActive = System.currentTimeMillis()
    private var lastReminder = System.currentTimeMillis()
    private var dimmed = false

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) ocr(uri)
    }
    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = photoUri
        if (ok && u != null) ocr(u)
    }
    private val startRunnable = Runnable { if (cooking && !speaking) startListening() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) {
                tts?.language = Locale.FRENCH
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { speaking = false; runOnUiThread { restart() } }
                    override fun onError(id: String?) { speaking = false; runOnUiThread { restart() } }
                })
            }
        }
        val need = mutableListOf<String>()
        if (!granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            need += Manifest.permission.POST_NOTIFICATIONS
        }
        if (need.isNotEmpty()) perms.launch(need.toTypedArray())
        refresh()
        loadRecipes()
        setContent { EcaApp() }
        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        wake()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onStop() {
        if (cooking) switchCooking(false)
        super.onStop()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------- Données ----------

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun refresh() { timers = TimerStore.load(this).sortedBy { it.endAt } }

    private fun loadRecipes() { recipes = RecipeStore.load(this).sortedBy { it.title.lowercase() } }

    private fun saveRecipe(r: Recipe) {
        RecipeStore.save(this, RecipeStore.load(this).filter { it.id != r.id } + r)
        loadRecipes()
    }

    private fun deleteRecipe(r: Recipe) {
        RecipeStore.save(this, RecipeStore.load(this).filter { it.id != r.id })
        loadRecipes()
    }

    private fun left(t: EcaTimer) = maxOf(0L, (t.endAt - System.currentTimeMillis()) / 1000)

    private fun addTimer(name: String, seconds: Long) {
        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val t = EcaTimer(id, name, System.currentTimeMillis() + seconds * 1000)
        TimerStore.save(this, TimerStore.load(this) + t)
        Alarms.schedule(this, t)
        refresh()
    }

    private fun removeTimer(t: EcaTimer) {
        Alarms.cancel(this, t)
        TimerStore.save(this, TimerStore.load(this).filter { it.id != t.id })
        refresh()
    }

    private fun find(q: String): EcaTimer? {
        if (q.isBlank()) return if (timers.size == 1) timers[0] else null
        val k = q.lowercase()
        return timers.firstOrNull { it.name.lowercase().contains(k) || k.contains(it.name.lowercase()) }
    }

    private fun notFound(q: String) =
        if (q.isBlank()) "Lequel ? Dis le nom du minuteur." else "Je ne trouve pas de minuteur $q."

    private fun fmtDate(t: Long) = SimpleDateFormat("dd/MM/yyyy 'à' HH:mm", Locale.FRANCE).format(Date(t))

    // ---------- Voix ----------

    private fun say(text: String) {
        reply = text
        if (cooking) {
            speaking = true
            recognizer?.cancel()
            handler.postDelayed({ if (speaking) { speaking = false; restart() } }, 10000)
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "eca")
    }

    private fun handle(text: String) {
        refresh()
        when (val c = Voice.parse(text)) {
            is Cmd.Start -> {
                addTimer(c.name, c.seconds)
                say("C'est parti : ${c.name}, ${Voice.fmt(c.seconds)}.")
            }
            is Cmd.Time -> {
                val cal = Calendar.getInstance()
                val m = cal.get(Calendar.MINUTE)
                say("Il est ${cal.get(Calendar.HOUR_OF_DAY)} heures" + if (m == 0) "." else " $m.")
            }
            is Cmd.Stop -> {
                getSystemService(NotificationManager::class.java).cancelAll()
                ringing = null
                val t = find(c.name)
                when {
                    t != null -> { removeTimer(t); say("Minuteur ${t.name} arrêté.") }
                    c.name.isBlank() -> say("D'accord, c'est coupé.")
                    else -> say(notFound(c.name))
                }
            }
            is Cmd.Remaining -> {
                val t = find(c.name)
                when {
                    t != null -> say("Il reste ${Voice.fmt(left(t))} pour ${t.name}.")
                    c.name.isBlank() && timers.isEmpty() -> say("Aucun minuteur en cours.")
                    c.name.isBlank() -> say(timers.joinToString(". ") { "${it.name} : ${Voice.fmt(left(it))}" })
                    else -> say(notFound(c.name))
                }
            }
            is Cmd.Open -> openRecipe(c.name)
            is Cmd.Next -> goStep(cookIndex + 1)
            is Cmd.Prev -> goStep(cookIndex - 1)
            is Cmd.Goto -> goStep(c.n - 1)
            is Cmd.Repeat -> goStep(cookIndex)
            is Cmd.Ingredients -> readIngredients()
            is Cmd.StepTimer -> startStepTimer()
            is Cmd.Unknown -> say(c.hint)
        }
    }

    // ---------- Import par lien ----------

    /** Réception d'un partage (« Partager > ECA ») : un lien, du texte, ou une image (capture d'écran). */
    private fun handleShare(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_SEND) return
        val stream = sharedStream(i)
        val text = i.getStringExtra(Intent.EXTRA_TEXT)
        i.action = null
        screen = "import"
        if (stream != null) ocr(stream)
        else if (text != null) startImport(text)
    }

    @Suppress("DEPRECATION")
    private fun sharedStream(i: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)

    private fun startImport(text: String) {
        val url = Importer.extractUrl(text)
        if (url == null) {
            importStatus = "Je ne vois pas de lien dans ce texte."
            return
        }
        importUrl = url
        importing = true
        importStatus = "Récupération de la recette…"
        Thread {
            val result: Any? = try {
                Importer.load(url)
            } catch (e: ImportException) {
                e.message
            } catch (e: Exception) {
                "Impossible de joindre le site : vérifie la connexion."
            }
            runOnUiThread {
                importing = false
                if (result is Imported) {
                    draft = Recipe(0L, result.title, result.ingredients, result.steps, System.currentTimeMillis(), result.source)
                    current = null
                    importStatus = ""
                    screen = "edit"
                } else {
                    importStatus = (result as? String) ?: "Erreur pendant l'import."
                }
            }
        }.start()
    }

    /** Lit le texte d'une image (page de livre, capture d'écran) sur le téléphone, sans connexion. */
    private fun ocr(uri: Uri) {
        importStatus = "Lecture de la photo…"
        try {
            val image = InputImage.fromFilePath(this, uri)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                .addOnSuccessListener { r ->
                    scanText = (scanText + "\n" + r.text).trim()
                    importStatus = "Texte lu. Corrige-le si besoin, ajoute une autre page, puis crée la recette."
                }
                .addOnFailureListener { importStatus = "Lecture impossible de cette image." }
        } catch (e: Exception) {
            importStatus = "Impossible d'ouvrir cette image."
        }
    }

    private fun launchCamera() {
        val f = File(cacheDir, "scan_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
        photoUri = uri
        takePhoto.launch(uri)
    }

    private fun createFromText(text: String) {
        if (text.isBlank()) { importStatus = "Il n'y a pas de texte."; return }
        val p = TextParser.parse(text)
        draft = Recipe(0L, p.title, p.ingredients, p.steps, System.currentTimeMillis(), "")
        current = null
        scanText = ""
        importStatus = ""
        screen = "edit"
    }

    private fun startCook(r: Recipe) {
        val steps = r.steps.lines().filter { it.isNotBlank() }
        if (steps.isEmpty()) { say("Cette recette n'a pas d'étapes."); return }
        current = r
        cookSteps = steps
        cookIndex = 0
        showIngredients = false
        screen = "cook"
        say("${r.title}. ${steps.size} étapes. Étape 1. ${steps[0]}")
    }

    private fun openRecipe(name: String) {
        if (name.isBlank()) { say("Quelle recette ?"); return }
        val k = name.lowercase()
        val r = recipes.firstOrNull { it.title.lowercase().contains(k) || k.contains(it.title.lowercase()) }
        if (r == null) say("Je ne trouve pas la recette $name.") else startCook(r)
    }

    private fun goStep(i: Int) {
        if (cookSteps.isEmpty()) {
            say("Aucune recette en cours. Dis : Chef, ouvre la recette, puis son nom.")
            return
        }
        when {
            i < 0 -> say("C'est déjà la première étape.")
            i >= cookSteps.size -> say("C'était la dernière étape. Bon appétit !")
            else -> { cookIndex = i; say("Étape ${i + 1}. ${cookSteps[i]}") }
        }
    }

    private fun readIngredients() {
        val r = current
        if (r == null || cookSteps.isEmpty()) { say("Aucune recette en cours."); return }
        showIngredients = true
        say("Ingrédients : " + r.ingredients.lines().filter { it.isNotBlank() }.joinToString(", "))
    }

    private fun startStepTimer() {
        val r = current
        if (r == null || cookSteps.isEmpty()) {
            say("Combien de temps ? Par exemple : minuteur pâte 45 minutes.")
            return
        }
        val secs = Voice.duration(cookSteps[cookIndex])
        if (secs <= 0) say("Pas de durée dans cette étape.")
        else {
            addTimer("${r.title} (étape ${cookIndex + 1})", secs)
            say("Minuteur lancé : ${Voice.fmt(secs)}.")
        }
    }

    /** Applique le mot d'activation « Chef » : seules les phrases qui le contiennent sont traitées en mode cuisine. */
    private fun process(text: String) {
        val m = Regex("\\bchef\\b[ ,.!?]*(.*)").find(text.lowercase())
        when {
            m != null -> {
                heard = text
                wake()
                val rest = m.groupValues[1].trim()
                if (Regex("(arrête|arrete|stop|désactive|desactive|quitte|coupe).*mode cuisine").containsMatchIn(rest)) {
                    switchCooking(false)
                    say("Mode cuisine désactivé.")
                } else if (rest.isBlank()) {
                    awaitUntil = System.currentTimeMillis() + 10000
                    say("Oui ?")
                } else handle(rest)
            }
            awaitUntil > System.currentTimeMillis() -> {
                awaitUntil = 0
                heard = text
                wake()
                handle(text)
            }
            !cooking -> { heard = text; handle(text) }
            else -> {} // mode cuisine : phrase sans « Chef », ignorée
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) { listening = true }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() { listening = false }
        override fun onError(e: Int) {
            listening = false
            if (cooking) {
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) switchCooking(false)
                else {
                    if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) recognizer?.cancel()
                    restart()
                }
            } else if (e != SpeechRecognizer.ERROR_CLIENT) {
                say("Je n'ai rien entendu, réessaie.")
            }
        }
        override fun onResults(res: Bundle?) {
            listening = false
            val text = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text != null) process(text)
            if (cooking) restart()
        }
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    private fun restart() {
        handler.removeCallbacks(startRunnable)
        if (cooking && !speaking) handler.postDelayed(startRunnable, 400)
    }

    private fun startListening() {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            cooking = false
            say("La reconnaissance vocale n'est pas disponible sur ce téléphone.")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        }
        recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        })
    }

    /** Bouton micro : la prochaine phrase est une commande, sans dire « Chef ». */
    private fun listen() {
        tts?.stop()
        speaking = false
        recognizer?.cancel()
        awaitUntil = System.currentTimeMillis() + 10000
        startListening()
    }

    /** Réveille l'écran : toute interaction (touche ou « Chef ») remet la luminosité du téléphone. */
    private fun wake() {
        lastActive = System.currentTimeMillis()
        if (dimmed) applyBrightness(false)
    }

    private fun applyBrightness(dim: Boolean) {
        val lp = window.attributes
        lp.screenBrightness = if (dim) 0.03f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
        dimmed = dim
    }

    private fun switchCooking(on: Boolean) {
        cooking = on
        if (on) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            lastActive = System.currentTimeMillis()
            lastReminder = lastActive
            say("Mode cuisine activé. Dis Chef, puis ta commande.")
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            applyBrightness(false)
            handler.removeCallbacks(startRunnable)
            recognizer?.cancel()
            tts?.stop()
            speaking = false
            listening = false
            reply = "Mode cuisine désactivé."
        }
    }

    // ---------- Interface ----------

    @Composable
    private fun EcaApp() {
        MaterialTheme(
            colorScheme = lightColorScheme(
                primary = Leaf, onPrimary = Color.White,
                background = Cream, onBackground = Deep,
                surface = Sage, onSurface = Deep
            )
        ) {
            LaunchedEffect(Unit) {
                while (true) {
                    now = System.currentTimeMillis()
                    refresh()
                    val old = prevTimers
                    prevTimers = timers
                    old.filter { o -> timers.none { it.id == o.id } && o.endAt <= now + 2500 }
                        .forEach { ringing = it.name }
                    if (cooking) {
                        if (!dimmed && now - lastActive > 15 * 60_000L) applyBrightness(true)
                        if (now - lastReminder > 3 * 3_600_000L) {
                            lastReminder = now
                            say("Le mode cuisine est actif depuis trois heures. Dis Chef, arrête le mode cuisine, quand tu as fini.")
                        }
                    }
                    delay(1000)
                }
            }
            BackHandler(enabled = screen != "home") {
                screen = when (screen) {
                    "edit" -> if (current != null) "detail" else "list"
                    "detail" -> "list"
                    "cook" -> "detail"
                    "import" -> "list"
                    else -> "home"
                }
            }
            Box(Modifier.fillMaxSize().background(Cream)) {
                when (screen) {
                    "list" -> RecipeList()
                    "detail" -> RecipeDetail()
                    "cook" -> CookScreen()
                    "import" -> ImportScreen()
                    "edit" -> RecipeEdit()
                    else -> Home()
                }
                if (bannerOn()) Box(Modifier.align(Alignment.TopCenter)) { Banner() }
            }
        }
    }

    private fun bannerOn() =
        (screen == "list" || screen == "detail" || screen == "cook") && (ringing != null || timers.isNotEmpty())

    /** Bandeau en surimpression : prochaine alarme, ou « c'est prêt ! » quand elle sonne. */
    @Composable
    private fun Banner() {
        val next = timers.minByOrNull { it.endAt }
        val r = ringing
        val ring = r != null
        Card(
            colors = CardDefaults.cardColors(containerColor = if (ring) Clay else Deep),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 12.dp)
                .clickable { if (ring) ringing = null else screen = "home" }
        ) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (ring) "⏰ $r : c'est prêt !" else "⏱ ${next?.name ?: ""}",
                    color = if (ring) Deep else Color.White,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (!ring && next != null) {
                    Text(
                        Voice.clock(maxOf(0L, (next.endAt - now) / 1000)),
                        color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    @Composable
    private fun Home() {
        var showAdd by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("🌿 Emma's Cook Assistant", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Leaf)
            Spacer(Modifier.height(12.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Sage),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date(now)),
                        fontSize = 60.sp, fontWeight = FontWeight.Light, color = Deep
                    )
                    Text(
                        SimpleDateFormat("EEEE d MMMM", Locale.FRANCE).format(Date(now))
                            .replaceFirstChar { it.uppercase() },
                        color = Deep
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { screen = "list" }, modifier = Modifier.weight(1f)) { Text("📖 Recettes") }
                Button(
                    onClick = { switchCooking(!cooking) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (cooking) Clay else Deep,
                        contentColor = if (cooking) Deep else Color.White
                    )
                ) { Text(if (cooking) "👂 Écoute activée" else "👂 Mode cuisine") }
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Minuteurs", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Deep, modifier = Modifier.weight(1f))
                TextButton(onClick = { showAdd = true }) { Text("+ Ajouter", color = Leaf) }
            }
            LazyColumn(Modifier.weight(1f)) {
                if (timers.isEmpty()) {
                    item { Text("Aucun minuteur en cours 🌱", color = Deep.copy(alpha = 0.6f), modifier = Modifier.padding(8.dp)) }
                }
                items(timers, key = { it.id }) { t ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(t.name, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Deep)
                                Text(Voice.clock(maxOf(0L, (t.endAt - now) / 1000)), fontSize = 28.sp, color = Leaf)
                            }
                            TextButton(onClick = { removeTimer(t) }) { Text("✕", fontSize = 20.sp, color = Clay) }
                        }
                    }
                }
            }
            if (heard.isNotBlank()) {
                Text("« $heard »", color = Deep.copy(alpha = 0.6f), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            Text(reply, color = Deep, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(8.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(80.dp).clip(CircleShape)
                        .background(if (listening) Clay else Leaf)
                        .clickable { listen() },
                    contentAlignment = Alignment.Center
                ) { Text("🎤", fontSize = 32.sp) }
            }
        }

        if (showAdd) {
            var name by remember { mutableStateOf("") }
            var min by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showAdd = false },
                title = { Text("Nouveau minuteur") },
                text = {
                    Column {
                        OutlinedTextField(name, { name = it }, label = { Text("Nom (pâte, gratin…)") }, singleLine = true)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(min, { min = it.filter(Char::isDigit) }, label = { Text("Minutes") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val m = min.toLongOrNull()
                        if (m != null && m > 0) {
                            addTimer(name.ifBlank { "Minuteur" }, m * 60)
                            showAdd = false
                        }
                    }) { Text("Lancer") }
                },
                dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Annuler") } }
            )
        }
    }

    @Composable
    private fun RecipeList() {
        var q by remember { mutableStateOf("") }
        val shown = recipes.filter { q.isBlank() || it.title.contains(q, true) || it.ingredients.contains(q, true) }
        Column(
            Modifier.fillMaxSize().padding(horizontal = 20.dp)
                .padding(top = if (bannerOn()) 76.dp else 20.dp, bottom = 20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { screen = "home" }) { Text("← Retour", color = Leaf) }
                Spacer(Modifier.weight(1f))
                Button(onClick = { importUrl = ""; importStatus = ""; screen = "import" }) { Text("🔗 Importer") }
                Spacer(Modifier.width(8.dp))
                Button(onClick = { current = null; draft = null; screen = "edit" }) { Text("+ Nouvelle") }
            }
            Text("Recettes", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Deep)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(q, { q = it }, label = { Text("Rechercher") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                if (shown.isEmpty()) {
                    item {
                        Text(
                            "Aucune recette pour l'instant 🌱\nAppuie sur « + Nouvelle recette ».",
                            color = Deep.copy(alpha = 0.6f), modifier = Modifier.padding(8.dp)
                        )
                    }
                }
                items(shown, key = { it.id }) { r ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                            .clickable { current = r; screen = "detail" }
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(r.title, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Deep)
                            Text("Modifiée le ${fmtDate(r.updatedAt)}", fontSize = 12.sp, color = Deep.copy(alpha = 0.6f))
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun RecipeDetail() {
        val r = current ?: return
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp).padding(top = if (bannerOn()) 76.dp else 20.dp, bottom = 20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { screen = "list" }) { Text("← Retour", color = Leaf) }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { screen = "edit" }) { Text("✏️ Modifier", color = Leaf) }
            }
            Text(r.title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Deep)
            Text("Modifiée le ${fmtDate(r.updatedAt)}", fontSize = 12.sp, color = Deep.copy(alpha = 0.6f))
            if (r.source.isNotBlank()) {
                TextButton(onClick = {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.source)))
                }) { Text("🔗 Page d'origine", color = Leaf) }
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = { startCook(r) }, modifier = Modifier.fillMaxWidth()) { Text("🍳 Cuisiner étape par étape") }
            Spacer(Modifier.height(16.dp))
            Text("Ingrédients", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Leaf)
            Text(r.ingredients, color = Deep, modifier = Modifier.padding(vertical = 6.dp))
            Spacer(Modifier.height(12.dp))
            Text("Étapes", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Leaf)
            r.steps.lines().filter { it.isNotBlank() }.forEachIndexed { i, line ->
                val secs = Voice.duration(line)
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}. $line", color = Deep, modifier = Modifier.weight(1f))
                        if (secs > 0) {
                            TextButton(onClick = { addTimer("${r.title} (étape ${i + 1})", secs) }) {
                                Text("⏱ ${Voice.fmt(secs)}", color = Leaf)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            TextButton(onClick = { deleteRecipe(r); current = null; screen = "list" }) {
                Text("🗑 Supprimer cette recette", color = Clay)
            }
        }
    }

    @Composable
    private fun CookScreen() {
        val r = current
        if (r == null || cookSteps.isEmpty()) return
        val idx = cookIndex.coerceIn(0, cookSteps.size - 1)
        val step = cookSteps[idx]
        val secs = Voice.duration(step)
        Column(
            Modifier.fillMaxSize().padding(horizontal = 20.dp)
                .padding(top = if (bannerOn()) 76.dp else 20.dp, bottom = 20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { screen = "detail" }) { Text("← Quitter", color = Leaf) }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { showIngredients = !showIngredients }) {
                    Text(if (showIngredients) "Masquer les ingrédients" else "🥕 Ingrédients", color = Leaf)
                }
            }
            Text(r.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Deep)
            Text("Étape ${idx + 1} / ${cookSteps.size}", color = Leaf, fontSize = 16.sp)
            Spacer(Modifier.height(12.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Sage),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth().weight(1f)
            ) {
                Column(Modifier.padding(24.dp).verticalScroll(rememberScrollState())) {
                    if (showIngredients) {
                        Text("Ingrédients", fontWeight = FontWeight.Bold, color = Leaf, fontSize = 18.sp)
                        Text(r.ingredients, color = Deep, fontSize = 20.sp, modifier = Modifier.padding(vertical = 8.dp))
                        Spacer(Modifier.height(12.dp))
                    }
                    Text(step, fontSize = 28.sp, lineHeight = 38.sp, color = Deep)
                    if (secs > 0) {
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = { startStepTimer() }) { Text("⏱ Lancer ${Voice.fmt(secs)}") }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            if (!cooking) {
                TextButton(onClick = { switchCooking(true) }, modifier = Modifier.fillMaxWidth()) {
                    Text("👂 Activer le mode « Chef » (mains libres)", color = Leaf)
                }
            } else {
                Text(
                    "👂 Dis « Chef, suivant », « Chef, répète »…",
                    color = Deep.copy(alpha = 0.6f), textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { goStep(idx - 1) }, modifier = Modifier.weight(1f)) { Text("◀") }
                Button(onClick = { listen() }, modifier = Modifier.weight(1f)) { Text("🎤") }
                Button(onClick = { goStep(idx) }, modifier = Modifier.weight(1f)) { Text("🔊") }
                Button(onClick = { goStep(idx + 1) }, modifier = Modifier.weight(1f)) { Text("▶") }
            }
        }
    }

    @Composable
    private fun ImportScreen() {
        var link by remember(importUrl) { mutableStateOf(importUrl) }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
            TextButton(onClick = { screen = "list" }) { Text("← Retour", color = Leaf) }
            Text("Importer une recette", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Deep)
            Spacer(Modifier.height(16.dp))
            Text("🔗 Depuis un lien", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Leaf)
            Text(
                "Marmiton, 750g, TikTok… Colle le lien, ou partage la page vers ECA depuis le navigateur.",
                color = Deep, modifier = Modifier.padding(vertical = 6.dp)
            )
            OutlinedTextField(link, { link = it }, label = { Text("Lien") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Button(onClick = { startImport(link) }, enabled = !importing, modifier = Modifier.fillMaxWidth()) {
                Text(if (importing) "Import en cours…" else "Importer le lien")
            }
            Spacer(Modifier.height(24.dp))
            Text("📄 Depuis un texte ou une photo", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Leaf)
            Text(
                "Page de livre, capture d'écran TikTok, texte copié : l'app lit le texte, tu le corriges, puis elle le range en ingrédients et étapes.",
                color = Deep, modifier = Modifier.padding(vertical = 6.dp)
            )
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { launchCamera() }, modifier = Modifier.weight(1f)) { Text("📷 Photo") }
                Button(onClick = { pickImage.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("🖼 Image") }
            }
            OutlinedTextField(
                scanText, { scanText = it }, label = { Text("Texte de la recette") },
                minLines = 6, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { createFromText(scanText) }, enabled = scanText.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Créer la recette") }
            if (importStatus.isNotBlank()) {
                Text(importStatus, color = if (importing) Deep else Clay, modifier = Modifier.padding(top = 12.dp))
            }
            Text(
                "Le lien demande une connexion. La lecture des photos se fait sur le téléphone. Tu pourras tout corriger avant d'enregistrer.",
                fontSize = 12.sp, color = Deep.copy(alpha = 0.6f), modifier = Modifier.padding(top = 16.dp)
            )
        }
    }

    @Composable
    private fun RecipeEdit() {
        val r = current
        val src = r ?: draft
        var title by remember { mutableStateOf(src?.title ?: "") }
        var ing by remember { mutableStateOf(src?.ingredients ?: "") }
        var steps by remember { mutableStateOf(src?.steps ?: "") }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { draft = null; screen = if (r != null) "detail" else "list" }) { Text("Annuler", color = Leaf) }
                Spacer(Modifier.weight(1f))
                Button(onClick = {
                    if (title.isNotBlank()) {
                        val saved = Recipe(
                            r?.id ?: System.currentTimeMillis(), title.trim(),
                            ing.trim(), steps.trim(), System.currentTimeMillis(), src?.source ?: ""
                        )
                        draft = null
                        saveRecipe(saved)
                        current = saved
                        screen = "detail"
                    }
                }) { Text("Enregistrer") }
            }
            Text(if (r != null) "Modifier la recette" else if (draft != null) "Recette importée : vérifie avant d'enregistrer" else "Nouvelle recette", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Deep)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(title, { title = it }, label = { Text("Nom de la recette") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(ing, { ing = it }, label = { Text("Ingrédients (un par ligne)") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(steps, { steps = it }, label = { Text("Étapes (une par ligne)") }, minLines = 6, modifier = Modifier.fillMaxWidth())
            Text(
                "Astuce : écris la durée dans l'étape (« Cuire 25 min ») et un bouton ⏱ apparaîtra pour lancer le minuteur.",
                fontSize = 12.sp, color = Deep.copy(alpha = 0.6f), modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
