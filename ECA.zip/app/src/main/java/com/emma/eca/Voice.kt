package com.emma.eca

sealed class Cmd {
    data class Start(val name: String, val seconds: Long) : Cmd()
    data class Stop(val name: String) : Cmd()
    data class Remaining(val name: String) : Cmd()
    object Time : Cmd()
    data class Open(val name: String) : Cmd()
    data class Goto(val n: Int) : Cmd()
    object Next : Cmd()
    object Prev : Cmd()
    object Repeat : Cmd()
    object Ingredients : Cmd()
    object StepTimer : Cmd()
    data class Unknown(val hint: String) : Cmd()
}

object Voice {
    private val numbers = mapOf(
        "un" to 1, "une" to 1, "deux" to 2, "trois" to 3, "quatre" to 4, "cinq" to 5,
        "six" to 6, "sept" to 7, "huit" to 8, "neuf" to 9, "dix" to 10, "onze" to 11,
        "douze" to 12, "quinze" to 15, "vingt" to 20, "trente" to 30, "quarante" to 40,
        "cinquante" to 50, "soixante" to 60
    )
    private val stopWords = setOf(
        "stop", "arrête", "arrete", "arrêter", "annule", "annuler",
        "supprime", "supprimer", "coupe", "éteins", "eteins"
    )
    private val nextWords = setOf("suivant", "suivante", "prochaine", "prochain", "next")
    private val prevWords = setOf("précédent", "précédente", "precedent", "precedente", "retour", "reviens", "recule")
    private val repeatWords = setOf("répète", "repete", "répéter", "repeter", "redis", "relis", "relire")
    private val openWords = setOf("ouvre", "ouvrir", "lance", "lancer", "cuisine", "cuisiner", "prépare", "prepare", "commence", "commencer")
    private val fillers = stopWords + nextWords + prevWords + repeatWords + openWords + setOf(
        "recette", "recettes", "étape", "etape", "ingrédients", "ingredients",
        "chef", "mets", "mettre", "met", "lance", "lancer", "démarre", "demarre", "programme",
        "règle", "regle", "un", "une", "le", "la", "les", "l", "du", "de", "des", "d",
        "pour", "minuteur", "minuteurs", "minuterie", "timer", "alarme", "s", "il", "te",
        "plait", "plaît", "stp", "moi", "ma", "mon", "mes", "pendant", "sur", "à", "a",
        "dans", "en", "et", "demie", "demi", "combien", "temps", "reste", "restant",
        "quel", "quelle", "est", "qui", "ce", "cette"
    )

    private fun unit(t: String?): Long? = when (t) {
        "seconde", "secondes", "sec" -> 1L
        "minute", "minutes", "min" -> 60L
        "heure", "heures", "h" -> 3600L
        else -> null
    }

    private fun num(t: String): Int? = t.toIntOrNull() ?: numbers[t]

    private fun normalize(raw: String): String {
        var s = raw.lowercase().replace("’", "'").replace("-", " ")
        s = Regex("(\\d+)\\s*h\\s*(\\d+)").replace(s, "$1 heures $2 minutes")
        s = Regex("(\\d)([a-zà-ÿ])").replace(s, "$1 $2")
        return s
    }

    private fun tokens(s: String) = s.split(" ", "'", ",", ".").filter { it.isNotBlank() }

    private fun scan(toks: List<String>): Pair<Long, List<String>> {
        val rest = mutableListOf<String>()
        var total = 0L
        var i = 0
        while (i < toks.size) {
            val t = toks[i]
            val n0 = num(t)
            when {
                t == "quart" -> {
                    var j = i + 1
                    if (toks.getOrNull(j) == "d") j++
                    if (unit(toks.getOrNull(j)) == 3600L) { total += 900; i = j + 1 }
                    else { rest.add(t); i++ }
                }
                t == "demi" && unit(toks.getOrNull(i + 1)) == 3600L -> { total += 1800; i += 2 }
                n0 != null -> {
                    var n = n0
                    var j = i + 1
                    val nx = toks.getOrNull(j)?.let { num(it) }
                    if (n >= 20 && n % 10 == 0 && nx != null && nx < 10 && unit(toks.getOrNull(j + 1)) != null) {
                        n += nx; j++
                    }
                    val u = unit(toks.getOrNull(j))
                    if (u != null) {
                        total += n * u
                        i = j + 1
                        if (toks.getOrNull(i) == "et" && toks.getOrNull(i + 1) in setOf("demie", "demi")) {
                            total += u / 2
                            i += 2
                        }
                    } else { rest.add(t); i++ }
                }
                else -> { rest.add(t); i++ }
            }
        }
        return Pair(total, rest)
    }

    /** Durée (en secondes) trouvée dans un texte, 0 si aucune. */
    fun duration(raw: String): Long = scan(tokens(normalize(raw))).first

    fun parse(raw: String): Cmd {
        val s = normalize(raw)
        if (Regex("quelle heure|l'heure").containsMatchIn(s) &&
            !s.contains("minuteur") && !Regex("\\d").containsMatchIn(s)
        ) return Cmd.Time

        val toks = tokens(s)
        val (total, rest) = scan(toks)
        val name = rest.filter { it !in fillers && it.toIntOrNull() == null }
            .joinToString(" ").trim().replaceFirstChar { it.uppercase() }
        val words = toks.toSet()
        val stepNum = rest.firstNotNullOfOrNull { num(it) }
        return when {
            words.any { it in stopWords } -> Cmd.Stop(name)
            words.any { it in nextWords } -> Cmd.Next
            words.any { it in prevWords } -> Cmd.Prev
            total == 0L && stepNum != null && ("étape" in words || "etape" in words) -> Cmd.Goto(stepNum)
            words.any { it in repeatWords } -> Cmd.Repeat
            "ingrédients" in words || "ingredients" in words -> Cmd.Ingredients
            "recette" in words && total == 0L && words.any { it in openWords } -> Cmd.Open(name)
            words.any { it == "reste" || it == "combien" || it == "restant" } -> Cmd.Remaining(name)
            total > 0 -> Cmd.Start(name.ifBlank { "Minuteur" }, total)
            "minuteur" in words || "minuterie" in words || "timer" in words -> Cmd.StepTimer
            else -> Cmd.Unknown("Je n'ai pas compris. Essaie : minuteur pâte 45 minutes.")
        }
    }

    fun fmt(s: Long): String {
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        val p = mutableListOf<String>()
        if (h > 0) p += "$h heure${if (h > 1) "s" else ""}"
        if (m > 0) p += "$m minute${if (m > 1) "s" else ""}"
        if (sec > 0 || p.isEmpty()) p += "$sec seconde${if (sec > 1) "s" else ""}"
        return p.joinToString(" ")
    }

    fun clock(s: Long): String {
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
    }
}
