package com.emma.eca

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

data class EcaTimer(val id: Int, val name: String, val endAt: Long)

object TimerStore {
    private fun prefs(c: Context) = c.getSharedPreferences("eca", Context.MODE_PRIVATE)

    fun load(c: Context): List<EcaTimer> {
        val arr = JSONArray(prefs(c).getString("timers", "[]") ?: "[]")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            EcaTimer(o.getInt("id"), o.getString("name"), o.getLong("endAt"))
        }
    }

    fun save(c: Context, list: List<EcaTimer>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("endAt", it.endAt)) }
        prefs(c).edit().putString("timers", arr.toString()).apply()
    }
}

object Alarms {
    private fun pending(c: Context, t: EcaTimer): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).putExtra("id", t.id).putExtra("name", t.name)
        return PendingIntent.getBroadcast(
            c, t.id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(c: Context, t: EcaTimer) {
        val am = c.getSystemService(AlarmManager::class.java)
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.endAt, pending(c, t))
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.endAt, pending(c, t))
        }
    }

    fun cancel(c: Context, t: EcaTimer) {
        c.getSystemService(AlarmManager::class.java).cancel(pending(c, t))
    }
}
