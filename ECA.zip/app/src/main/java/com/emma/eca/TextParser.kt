package com.emma.eca

data class ParsedRecipe(val title: String, val ingredients: String, val steps: String)

/** Transforme un texte brut (légende TikTok, photo de livre lue par OCR, texte collé) en recette. */
object TextParser {
    private val ingHeaders = listOf(
        "ingrédients", "ingredients", "il vous faut", "il te faut", "tu auras besoin", "vous aurez besoin"
    )
    private val stepHeaders = listOf(
        "préparation", "preparation", "étapes", "etapes", "instructions",
        "réalisation", "realisation", "méthode", "methode", "procédure", "pas à pas"
    )
    private val stopHeaders = listOf(
        "commentaire", "recettes similaires", "vous aimerez", "à lire aussi",
        "newsletter", "sur le même thème", "articles liés"
    )

    private data class Header(val ingredients: Boolean, val rest: String)

    private val stepStart = Regex("^[^\\p{L}\\p{N}]*(\\d+\\s*[.)]\\s*\\p{L}|[ée]tape\\s*\\d)", RegexOption.IGNORE_CASE)
    private val numRe = Regex("^(?:\\d+\\s*[.)](?!\\d)|\\d+\\s+[-:]\\s+|[ée]tape\\s*\\d+\\s*[:.)\\-]?)\\s*", RegexOption.IGNORE_CASE)
    private val unitRe = Regex(
        "^(?:[-•*·●▪✔✅]\\s*)?(?:\\d+(?:[.,/]\\d+)?\\s*(?:g|kg|mg|ml|cl|dl|l|c\\.?\\s*à\\s*[sc]\\.?|cuillères?|càs|càc|pincées?|verres?|tasses?|sachets?|gousses?|tranches?|boîtes?|pots?)\\b|\\d+\\s+\\p{L}+|une?\\s+(?:pincée|gousse|noix|cuillère|tranche)|quelques|un peu de|sel\\b|poivre\\b)",
        RegexOption.IGNORE_CASE
    )

    private fun norm(s: String) =
        s.lowercase().replace(Regex("[^\\p{L} ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun header(line: String): Header? {
        val n = norm(line)
        val ing = ingHeaders.firstOrNull { n.startsWith(it) }
        val kw = ing ?: stepHeaders.firstOrNull { n.startsWith(it) } ?: return null
        val colon = line.indexOfFirst { it == ':' || it == '：' }
        if (colon < 0 && n.length > kw.length + 30) return null
        if (colon > 60) return null
        val rest = if (colon >= 0) line.substring(colon + 1).trim() else ""
        return Header(ing != null, rest)
    }

    private fun isStop(line: String): Boolean {
        val n = norm(line)
        return stopHeaders.any { n.startsWith(it) && n.length <= it.length + 20 }
    }

    private fun isIngredientLine(l: String) =
        l.length <= 70 && unitRe.containsMatchIn(l) && !Regex("^\\d+\\s*[.)]\\s+").containsMatchIn(l)

    fun splitLong(s: String): List<String> =
        if (s.length > 300) s.split(Regex("(?<=[.!?])\\s+(?=\\p{Lu})")).map { it.trim() }.filter { it.isNotBlank() }
        else listOf(s)

    /** Découpe en phrases : chaque phrase devient une étape (plus facile à lire à voix haute). */
    private fun splitAll(s: String): List<String> =
        s.split(Regex("(?<=[.!?])\\s+(?=\\p{Lu})")).map { it.trim() }.filter { it.isNotBlank() }

    private fun endsSentence(s: String) = s.isNotEmpty() && s.last() in ".!?:"

    private fun mergeSteps(lines: List<String>): List<String> {
        val out = mutableListOf<String>()
        for (raw in lines) {
            val l = raw.replace(Regex("^[^\\p{L}\\p{N}]+"), "")
            if (l.isEmpty()) continue
            val numbered = numRe.containsMatchIn(l)
            val c = numRe.replace(l, "").trim()
            if (c.isEmpty()) continue
            val prev = out.lastOrNull()
            if (!numbered && prev != null && !endsSentence(prev) && c.first().isLowerCase()) {
                out[out.lastIndex] = if (prev.endsWith("-")) prev.dropLast(1) + c else "$prev $c"
            } else out.add(c)
        }
        return out.flatMap { splitAll(it) }
    }

    fun parse(raw: String, titleHint: String? = null): ParsedRecipe {
        val lines = raw.replace("\r", "")
            .replace(Regex("(?i)\\s+(?=(?:ingr[ée]dients?|pr[ée]paration|[ée]tapes|instructions|r[ée]alisation|m[ée]thode)\\s*:)"), "\n")
            .replace(Regex("(?<=\\S)[ \\t]+(?=\\d{1,2}[.)]\\s+\\p{Lu})"), "\n")
            .lines()
            .map { it.replace(Regex("(^|\\s)[#@][\\p{L}\\p{N}_]+"), " ").trim() }
            .filter { it.isNotBlank() }
        val head = mutableListOf<String>()
        val ing = mutableListOf<String>()
        val st = mutableListOf<String>()
        var mode = 0
        var seen = false
        for (l in lines) {
            if (mode == 2 && isStop(l)) break
            val h = header(l)
            if (h != null) {
                seen = true
                mode = if (h.ingredients) 1 else 2
                if (h.rest.isNotBlank()) (if (mode == 1) ing else st).add(h.rest)
                continue
            }
            when (mode) {
                0 -> head.add(l)
                1 -> ing.add(l)
                else -> st.add(l)
            }
        }
        if (seen) {
            // étapes numérotées glissées dans la liste d'ingrédients
            val k = ing.indexOfFirst { stepStart.containsMatchIn(it) }
            if (k >= 0) {
                st.addAll(0, ing.subList(k, ing.size).toList())
                while (ing.size > k) ing.removeAt(ing.size - 1)
            }
        } else if (lines.isNotEmpty()) {
            head.clear()
            head.add(lines.first())
            for (l in lines.drop(1)) if (isIngredientLine(l)) ing.add(l) else st.add(l)
        }
        if (ing.size == 1 && ing[0].length > 40) {
            val parts = ing[0].split(Regex("\\s*(?:,\\s+|;\\s*|•\\s*)")).filter { it.isNotBlank() }
            if (parts.size >= 3) { ing.clear(); ing.addAll(parts) }
        }
        val title = (titleHint?.takeIf { it.isNotBlank() } ?: head.firstOrNull() ?: "Recette importée")
            .replace(Regex("^[^\\p{L}\\p{N}]+|[^\\p{L}\\p{N}.!?)]+$"), "")
            .take(80).trim().ifBlank { "Recette importée" }
        val ingredients = ing.map { it.replace(Regex("^[^\\p{L}\\p{N}]+"), "").trim() }.filter { it.isNotBlank() }
        return ParsedRecipe(title, ingredients.joinToString("\n"), mergeSteps(st).joinToString("\n"))
    }
}
