package com.emma.eca

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Recipe(
    val id: Long,
    val title: String,
    val ingredients: String,
    val steps: String,
    val updatedAt: Long,
    val source: String = ""
)

object RecipeStore {
    private fun prefs(c: Context) = c.getSharedPreferences("eca_recipes", Context.MODE_PRIVATE)

    fun load(c: Context): List<Recipe> {
        val arr = JSONArray(prefs(c).getString("recipes", "[]") ?: "[]")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Recipe(
                o.getLong("id"), o.getString("title"), o.getString("ingredients"),
                o.getString("steps"), o.getLong("updatedAt"), o.optString("source", "")
            )
        }
    }

    fun save(c: Context, list: List<Recipe>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title)
                    .put("ingredients", it.ingredients).put("steps", it.steps)
                    .put("updatedAt", it.updatedAt).put("source", it.source)
            )
        }
        prefs(c).edit().putString("recipes", arr.toString()).apply()
    }
}
