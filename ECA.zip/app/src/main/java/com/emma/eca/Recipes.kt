package com.emma.eca

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Recipe(
    val id: Long,
    val title: String,
    val ingredients: String,
    val steps: String,
    val updatedAt: Long,
    val source: String = ""
)

object RecipeStore {
    private fun prefs(c: Context) = c.getSharedPreferences("eca_recipes", Context.MODE_PRIVATE)

    fun load(c: Context): List<Recipe> {
        val arr = JSONArray(prefs(c).getString("recipes", "[]") ?: "[]")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Recipe(
                o.getLong("id"), o.getString("title"), o.getString("ingredients"),
                o.getString("steps"), o.getLong("updatedAt"), o.optString("source", "")
            )
        }
    }

    fun save(c: Context, list: List<Recipe>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title)
                    .put("ingredients", it.ingredients).put("steps", it.steps)
                    .put("updatedAt", it.updatedAt).put("source", it.source)
            )
        }
        prefs(c).edit().putString("recipes", arr.toString()).apply()
    }

    /** Fichier de sauvegarde complet (restaurable). */
    fun toJson(list: List<Recipe>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title)
                    .put("ingredients", it.ingredients).put("steps", it.steps)
                    .put("updatedAt", it.updatedAt).put("source", it.source)
            )
        }
        return JSONObject().put("app", "ECA").put("version", 1)
            .put("exportedAt", System.currentTimeMillis()).put("recipes", arr).toString(2)
    }

    /** Lit un fichier de sauvegarde. Lève une exception si ce n'est pas une sauvegarde ECA. */
    fun fromJson(text: String): List<Recipe> {
        val v = JSONTokener(text.trim().removePrefix("\uFEFF")).nextValue()
        val arr = when (v) {
            is JSONArray -> v
            is JSONObject -> v.getJSONArray("recipes")
            else -> throw IllegalArgumentException("format")
        }
        val out = mutableListOf<Recipe>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val title = o.optString("title", "").trim()
            if (title.isEmpty()) continue
            out.add(
                Recipe(
                    o.optLong("id", System.currentTimeMillis() + i), title,
                    o.optString("ingredients", ""), o.optString("steps", ""),
                    o.optLong("updatedAt", System.currentTimeMillis()), o.optString("source", "")
                )
            )
        }
        return out
    }

    /** Version lisible (pour garder, imprimer ou relire les recettes). */
    fun toText(list: List<Recipe>): String {
        val df = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE)
        return list.sortedBy { it.title.lowercase() }.joinToString("\n\n----------------------------------------\n\n") { r ->
            buildString {
                appendLine(r.title.uppercase())
                appendLine("Modifiée le ${df.format(Date(r.updatedAt))}")
                if (r.source.isNotBlank()) appendLine("Source : ${r.source}")
                appendLine()
                appendLine("INGRÉDIENTS")
                r.ingredients.lines().filter { it.isNotBlank() }.forEach { appendLine("- $it") }
                appendLine()
                appendLine("ÉTAPES")
                r.steps.lines().filter { it.isNotBlank() }.forEachIndexed { i, l -> appendLine("${i + 1}. $l") }
            }.trimEnd()
        }
    }
}
